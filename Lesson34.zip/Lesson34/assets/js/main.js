
$(function(){

    

    const filmDB='http://omdbapi.com';
    const i = '?i=tt3896198';
    const apiKey='apikey=7c130cb8';
    $('#searchButton').on('click', function(event){

        const filmTop = $('#filmRight')
        filmTop.html('')
        filmTop.css('border', 'none')
   
        let pageNum = 1;
        let movieName = $('#search').val();
        let movieType = $('#type').val(); 

        // console.log(movieName)
        // console.log(movieType)
        
        async function getSearch(){
            filmTop.html('')
            filmTop.css('border', 'none')

            if(movieName !== '' && movieType !== 'undefined'){
                filmTop.html('')
                filmTop.css('border', 'none')
                
                console.log(pageNum)
                const responce = await fetch(`${filmDB}/?s=${movieName}&type=${movieType}&${apiKey}&page=${pageNum}`)
                const respJson = await responce.json()
                console.log(respJson)
                const respJsonSearch = respJson.Search;
                console.log(respJsonSearch);

                
                for(let f = 0; f <=respJsonSearch.length; f++){
                    const filmItem = $(`<div class="film__item"></div>`)
                    filmItem.css('border', '2px solid brown')
                    filmItem.append($(`<h1 class="film__title">Film Name: ${respJsonSearch[f].Title}</h1>`));
                    
                    filmItem.append($(`<div class="film__add"><span class="film__add-el">Year:</span><span class="film__info"> ${respJsonSearch[f].Year}</span></div>`));
                    filmItem.append($(`<div class="film__add"><span class="film__add-el">Type:</span><span class="film__info"> ${respJsonSearch[f].Type}</span></div>`));                    
                    if(respJsonSearch[f].Poster !== 'N/A'){
                        filmItem.append($(`<img class='film__poster' src="${respJsonSearch[f].Poster}">`));
                    }else{
                        filmItem.append($(`<img class='film__poster' src="https://cdn2.wpbeginner.com/wp-content/uploads/2013/04/wp404error.jpg">`));
                    }

                    filmTop.append(filmItem);
                    
                }

            } else{
                alert('Write Name and choose Type')
            }

        
        }
        let items = document.querySelectorAll('#pagination li');
        for(let item of items){
            item.addEventListener('click', function(){
                console.log('click');
                filmTop.html('')
                filmTop.css('border', 'none')

                pageNum = +this.innerHTML;
                console.log(pageNum)
                getSearch();
            });
        }
        
        getSearch();
    })

    
    
})












